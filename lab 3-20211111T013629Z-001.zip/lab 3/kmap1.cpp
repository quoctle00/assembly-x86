#include <iostream>
using namespace std;

bool kmap1(bool a, bool b, bool c, bool d){
  //a'cd + a'b +bc'
  //011 + 01 +10
  if(!a && c && d || !a && b || b && !c) {
    cout << "true" << endl;
    return true;
  }
  else {
    cout << "false" << endl;
    return 0;
  }

}

int main(){
  int a;
  int b;
  int c;
  int d;
  cout << "equation is: A'CD + A'B + BC'" << endl;
  cout << "enter values for A: " << endl;
  cin >> a;
  cout << "enter values for B: " << endl;
  cin >> b;
  cout << "enter values for C: " << endl;
  cin >> c;
  cout << "enter values for D: " << endl;
  cin >> d;
  kmap1(a,b,c,d);
}
