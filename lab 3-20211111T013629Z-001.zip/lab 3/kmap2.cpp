#include <iostream>
using namespace std;

bool kmap2(bool a, bool b, bool c, bool d){
  //a'b' + a'c + b'c
  if(!a && !b || !a && c || !b && c) {
    cout << "true" << endl;
    return true;
  }
  else {
    cout << "false" << endl;
    return 0;
  }
}


int main(){
  int a;
  int b;
  int c;
  int d;
  cout << "equation is: A'B + A'C + B'C" << endl;
  cout << "enter values for A: " << endl;
  cin >> a;
  cout << "enter values for B: " << endl;
  cin >> b;
  cout << "enter values for C: " << endl;
  cin >> c;
  cout << "enter values for D: " << endl;
  cin >> d;
  kmap2(a,b,c,d);
}
