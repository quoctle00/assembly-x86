#include <iostream>
using namespace std;

// function to convert decimal to hexadecimal
void decimalToHexadecimal(int n) {
    // char array to store hexadecimal number
    char hexaDeciNum[1000];
    // counter for hexadecimal number array
    int i = 0;
    while(n!=0) {
        // temporary variable to store remainder
        int tempStore  = 0;
        // storing remainder in temp variable.
        tempStore = n % 16;
        // check if temp < 10
        if(tempStore < 10) {
            hexaDeciNum[i] = tempStore + 48;
            i++;
        }
        else {
            hexaDeciNum[i] = tempStore + 55;
            i++;
        }
        n = n/16;
    }
    // printing hexadecimal number array in reverse order
    for(int j=i-1; j>=0; j--){
      cout << hexaDeciNum[j];
    }
}
// Driver program to run the above function
int main() {
    int n;
    cout << "Enter the decimal value" << endl << "Input: ";
    cin >> n;
    cout << "Output: ";
    decimalToHexadecimal(n);
    cout << endl;

    return 0;
}
