#include <iostream>
using namespace std;

// Function to convert binary to decimal
int binaryToDecimal(int n) {
    int number = n;
    int decimalValue = 0;
    // Initializing base value to 1, i.e 2^0
    int baseValue = 1;
    int tempStore = number;
    while (tempStore) {
        int lastDigit = tempStore % 10;
        tempStore = tempStore / 10;
        decimalValue += lastDigit * baseValue;
        baseValue = baseValue * 2;
    }
    return decimalValue;
}

// Driver program to test above function
int main() {
    int number;
    cout << "Enter the binary value" << endl << "Input: ";
    cin >> number;
    cout << "Output: ";
    cout << binaryToDecimal(number) << endl;

}
