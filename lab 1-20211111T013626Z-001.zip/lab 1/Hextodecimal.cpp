#include<iostream>
#include<string.h>    //need to include this for program to work
using namespace std;  //due to strlen being used.
//convert hexadecimal to decimal
int hexToDecimal(char hex[]) {
   int length = strlen(hex);  //get string length
   int baseValue = 1;
   int tempStore = 0;
   //loop to read through the string
   for (int i=length-1; i>=0; i--) {
      if (hex[i]>='0' && hex[i]<='9') {
         tempStore += (hex[i] - 48)*baseValue;
         baseValue = baseValue * 16;
      }
      else if (hex[i]>='A' && hex[i]<='F') {
         tempStore += (hex[i] - 55)*baseValue;
         baseValue = baseValue*16;
      }
   }
   return tempStore;
}
int main() {
  char hexValue[] = "";
  cout << "Input: ";
  cin >> hexValue;
  cout<<"Output: "<<hexToDecimal(hexValue)<<endl;
  return 0;
}
